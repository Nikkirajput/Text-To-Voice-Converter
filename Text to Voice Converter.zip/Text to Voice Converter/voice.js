let speech = new SpeechSynthesisUtterance()
let mybtn = document.querySelector("button")
mybtn.addEventListener('click', ()=>{
    speech.text = document.querySelector('textarea').value
    speech.rate = 0.5;
    speech.lang = 'Hi-IN';
    window.speechSynthesis.speak(speech)
})